# DB notes (26-question series)
- Schema: txn(txn_id, ts_utc TEXT 'YYYY-MM-DD HH:MM:SS', terminal_id, amount_minor, currency_id, status_id, response_code, route_id, latency_ms, card_scheme)
- txn_status_dict: 1 AUTHORIZED, 2 CAPTURED, 3 FAILED, 4 REVERSED, 5 REFUNDED
- dim_currency: exponent per currency (JPY=0, KWD=3, rest=2). EUR amount = amount_minor / 10^exponent
- fx_rate(rate_date TEXT, currency_id, rate_to_eur): multiply by rate_to_eur for EUR value; use rate_date = date of txn
- Q1 answer (CAPTURED txns 2025-03-14 UTC in EUR @ 2025-03-14 rates): 36531.85
- Other tables: settlement(fx_rate_applied), service_event, incident, deployment, config_change, fee_schedule, route, dim_merchant/group/mcc, dim_terminal(_model), terminal_assignment, response_code_dict(is_decline)
- Q2 answer: 2025-W51 (Dec 15-21, 2025) most txns (any status) for Helios Grocery (group 10 + subs 11,12,13,14; = 3321). Terminal->merchant via terminal_assignment valid at ts_utc (no gaps/overlaps). ISO week via julianday(monday)-julianday(mon of week1)/7; SQLite 3.40 lacks %V/%G.
